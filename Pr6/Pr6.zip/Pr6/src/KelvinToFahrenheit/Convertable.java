package KelvinToFahrenheit;

public interface Convertable {
    void convert();
}
