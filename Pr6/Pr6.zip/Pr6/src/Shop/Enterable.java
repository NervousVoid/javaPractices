package Shop;

public interface Enterable {
    void setName();
    void setPrice();
    void setFreq();
    void setWidthAndHeight();
}
