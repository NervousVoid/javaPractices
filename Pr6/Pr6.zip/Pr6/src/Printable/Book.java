package Printable;

public class Book implements Printable{
    public void print() {
        System.out.println("This is a book");
    }
}
