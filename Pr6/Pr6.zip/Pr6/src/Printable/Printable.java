package Printable;

public interface Printable {
    void print();
}
