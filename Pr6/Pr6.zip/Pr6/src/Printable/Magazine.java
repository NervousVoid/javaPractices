package Printable;

public class Magazine implements Printable{
    public void print(){
        System.out.println("This is a magazine");
    }
}
