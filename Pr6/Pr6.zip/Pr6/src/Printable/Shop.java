package Printable;

public class Shop implements Printable{

    public void print(){
        System.out.println("This is a shop");
    }
}
