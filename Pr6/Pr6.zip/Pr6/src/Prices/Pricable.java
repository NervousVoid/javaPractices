package Prices;

public interface Pricable {
    public int getPrice();
}
