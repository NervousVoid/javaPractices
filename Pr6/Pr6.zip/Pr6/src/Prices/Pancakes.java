package Prices;

public class Pancakes {
    private int price = 20;
    public int getPrice(){
        return price;
    }
}
