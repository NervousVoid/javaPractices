package Prices;

public class Tshirt implements Pricable{
    private int price = 100;

    public int getPrice(){
        return price;
    }
}
